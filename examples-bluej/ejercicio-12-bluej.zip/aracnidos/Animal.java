
/**
 * Clase base Animal con atributos compartidos.
 *
 * @author (your name)
 * @version 1.0.0
 */
public abstract class Animal
{
    private String name;
    private int weight;
    private int lives;
    private int legs;
    
    /**
     * Constructor for objects of class Animal
     */
    public Animal(String name, int legs)
    {
        // initialise instance variables
        this.name = name;
        this.legs = legs;
        this.weight = 1;
        this.lives = 1;
    }
    
    public void killAnimal () {
        this.lives = 0;
    }
    
    public boolean isAlive() {
        return this.lives > 0;
    }
    
    public boolean feed () {
        if(!this.isAlive()) {
            return false;
        }
        
        this.weight++;
        return true;
    }
    
    public void setName (String name) {
        this.name = name;
    }
    
    public String getName () {
        return this.name;
    }

    public int getLegs () {
        return this.legs;
    }
    
    public int getWeight () {
        return this.weight;
    }
}
