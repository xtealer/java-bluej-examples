import javax.swing.JOptionPane;

/**
 * Clase de animal tipo Escorpion.
 *
 * @author (your name)
 * @version 1.0.0
 */
public class Scorpion extends Animal
{
    // instance variables - replace the example below with your own
    final String animalType = "Escorpion";

    /**
     * Constructor for objects of class Scorpion
     */
    public Scorpion(String name)
    {
        // initialise instance variables
        super(name, 8);
    }
    
    public void alimentar() {
        final boolean didFeed = this.feed();
        String msg = "";
        
        if (didFeed) {        
            JOptionPane.showMessageDialog(null, this.getName() +", tu Nuevo peso es: " + this.getWeight());
            return;
        }
        
        msg += "ERROR: No puede alimentar un animal que haya muerto.\n\n";
        msg += "Nombre: " + this.getName();
        msg += "\nTipo de Animal: " + animalType;
        msg += "\nPatas: " + this.getLegs();
        msg += "\nPeso: " + this.getWeight();
        msg += "\nEstado: Muerto";
        
        JOptionPane.showMessageDialog(null, msg);
    }

    public void matar() {
        this.killAnimal();
        
        String msg = "";
            
        msg += "Nombre: " + this.getName();
        msg += "\nTipo de Animal: " + animalType;
        msg += "\nPatas: " + this.getLegs();
        msg += "\nPeso: " + this.getWeight();
        msg += "\nEstado: Muerto";
        
        JOptionPane.showMessageDialog(null, msg);
    }

    public void quienSos() {
        final boolean alive = this.isAlive();
        String status = "Vivo";
        String msg = "";
            
        if (!alive) {
            status = "Muerto";
        }
            
        msg += "Nombre: " + this.getName();
        msg += "\nTipo de Animal: " + animalType;
        msg += "\nPatas: " + this.getLegs();
        msg += "\nPeso: " + this.getWeight();
        msg += "\nEstado: " + status;
            
        JOptionPane.showMessageDialog(null, msg);
    }
}
